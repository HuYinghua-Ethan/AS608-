/**
* @file		as608.c
* @brief	AS608指纹识别
* @version  1.0
* @author   Ethan
* @date     2024.7.13
*/

/*
* 串行协议：采用半双工异步串行通讯。默认波特率为 57600bps，可通过命令设置为 9600～115200bps。
*           传送的帧格式为 10 位，一位 0 电平起始位，8 位数据（低位在前）和一位停止位，无校验位。
* 上电延时时间: 模块上电后，约需 500mS 时间进行初始化工作。在此期间，模块不能响应上位机命令。
* 缓冲区:模块 RAM 内设有一个图像缓冲区 ImageBuffer 与二个 512 bytes 大小的特征文件缓冲区CharBuffer1 和 CharBuffer2。
  用户可以通过指令读写任意一个缓冲区。图像缓冲区和两个特征文件缓冲区中的内容在模块断电时不保存。
* 特征文件缓冲区 CharBuffer1 或 CharBuffer2 既可以用于存放普通特征文件也可以用于存放模板特征文件
* 模块口令 : 模块上电复位后，将首先检查设备握手口令是否被修改。
  若未被修改，则模块认为上位机没有验证口令的需求，直接进入正常工作状态；即模块口令为默认口令时，可以不验证口令。
  口令为 4 字节, 出厂时默认口令为：0FFH,0FFH,0FFH,0FFH。
  如果模块内部口令已经被修改过（参见设置口令指令 SetPwd），则必须首先验证设备握手口令，口令通过后模块才进入正常工作状态。否则模块拒绝执行任何指令。
  口令修改后，新口令保存于 Flash 中，断电依然保存。
* 模块地址 : 每个模块都有一个识别地址，在模块与上位机通讯时，每条指令/数据都以数据包的形式传送，每个数据包都包含一个地址都包含地址项。
  模块只对包含与自身地址相同的地址的指令和数据包有所反应。
  模块地址为 4 字节，出厂时默认缺省值为：0xFFFFFFFF。用户可通过指令修改模块地址。模块地址修改后，新地址在模块断电后依然保存。 
* 数据包格式 (模块与上位机通讯，对命令、数据、结果的接收和发送，都采用数据包的形式进行)
   ____________________________________________________________________
  |包头 | 地址码  | 包标识  | 包长度   | 包内容(指令/数据/参数) | 校验和 |
  |_____|_________|________|__________|________________________|_______|
* 数据包的校验与应答
  指令只能由上位机下给模块，模块向上位机应答。
  模块收到指令后，会通过应答包，将有关命令执行情况与结果上报给上位机。
  应答包含有参数，并可跟后续数据包。
  上位机只有在收到模块的应答包后才能确认模块的收包情况与指令执行情况。
  应答包的内容包括一个字节的确认码（必须有）和可能有的返回参数。
  确认码定义表：
  1. 00h：表示指令执行完毕或 OK；
  2. 01h：表示数据包接收错误；
  3. 02h：表示传感器上没有手指；
  4. 03h：表示录入指纹图像失败；
  5. 06h：表示指纹图像太乱而生不成特征；
  6. 07h：表示指纹图像正常，但特征点太少（或面积太小）而生不成特征；
  7. 08h：表示指纹不匹配；
  8. 09h：表示没搜索到指纹；
  9. 0Ah：表示特征合并失败；
  10. 0Bh：表示访问指纹库时地址序号超出指纹库范围；
  11. 0Ch：表示从指纹库读模板出错或无效；
  12. 0Dh：表示上传特征失败；
  13. 0Eh：表示模块不能接受后续数据包；
  14. 0Fh：表示上传图像失败；
  15. 10h：表示删除模板失败；
  16. 11h：表示清空指纹库失败；
  17. 13h：表示口令不正确；
  18. 15H：表示缓冲区内没有有效原始图而生不成图像；
  19. 18H：表示读写 FLASH 出错；
  20. 19H：未定义错误；
  21. 1AH：无效寄存器号；
  22. 1BH：寄存器设定内容错误号；
  23. 1CH：记事本页码指定错误；
  24. 1DH：端口操作失败；
  25．其它：系统保留
*/


#include <string.h>
#include "as608.h"
#include "delay.h" 	
#include "usart2.h"
#include "as608.h"
#include "lcd12864.h"
#include "button.h"

u32 AS608Addr = 0XFFFFFFFF; //默认地址

u8 zhiwen_key;       //按键值
SysPara AS608Para;   //指纹模块AS608参数	
u8 zhi_wen_flag = 0; //判断指纹是否正确标志
u16 zhiwen_ID = 0;   //刷卡后存放指纹ID号
u16 ValidN;			 //模块内有效指纹个数
u8 add_zhiwen_flag=0;  	//判断录取指纹是否成功


extern u8 state;     //主函数菜单状态
/**
* @Description	AS608指纹识别模块初始化  PA1
* @param	None
* @return   None
*/
void PS_StaGPIO_Init(void)
{   
  GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//使能GPIOA时钟

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;		//输入下拉模式
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //50MHz
  GPIO_Init(GPIOA, &GPIO_InitStructure);			//初始化GPIO	
}


/**
* @Description	串口2发送字节
* @param	data 要发送的字节
  USART2->SR 是USART2的状态寄存器，用于存储各种状态标志位。
  0X40 是十六进制表示，对应于二进制的 0b01000000，它对应于USART的数据寄存器空标志位
  USART2->SR & 0X40 的操作是检查 TXE 标志位是否为1，即检查数据寄存器是否为空，可以发送新的数据。
  while((USART2->SR & 0X40) == 0); 这一行代码是一个忙等待循环，意味着程序会一直在这里等待，直到 TXE 标志位为1，表示可以发送数据。
  USART2->DR = data;  ：
  当 TXE 标志位为1时（即上述 while 循环退出），程序会将参数 data 的值写入到 USART2->DR 寄存器中。
  USART2->DR 是USART2的数据寄存器，用于存放要发送的数据。
* @return   None
*/
static void MYUSART_SendData(u8 data)
{
	while((USART2->SR&0X40)==0);
	USART2->DR = data;
}


/**
* @Description	发送包头
* @param	None
* @return   None
*/
static void SendHead(void)
{
	MYUSART_SendData(0xEF);
	MYUSART_SendData(0x01);
}


/**
* @Description	发送地址
* @param	None
* @return   None
*/
static void SendAddr(void)
{
	MYUSART_SendData(AS608Addr>>24);
	MYUSART_SendData(AS608Addr>>16);
	MYUSART_SendData(AS608Addr>>8);
	MYUSART_SendData(AS608Addr);
}


/**
* @Description	发送包标识
* @param	flag 包标识
* @return   None
*/
static void SendFlag(u8 flag)
{
	MYUSART_SendData(flag);
}


/**
* @Description	发送包长度
* @param	length 包长度
* @return   None
*/
static void SendLength(int length)
{
	MYUSART_SendData(length>>8);
	MYUSART_SendData(length);
}


/**
* @Description	发送指令码
* @param	cmd 要发送的指令
* @return   None
*/
static void SendCmd(u8 cmd)
{
	MYUSART_SendData(cmd);
}


/**
* @Description	发送校验码
* @param	check 校验码
* @return   None
*/
static void SendCheck(u16 check)
{
	MYUSART_SendData(check>>8);
	MYUSART_SendData(check);
}

/******************************* 下面是AS608	驱动代码 *******************************/

/**
* @Description	判断中断接收的数组有没有应答包
* @param	waittime: 等待中断接收数据的时间（单位:1ms）
* @return   数据包首地址
*/
/**
strstr()函数
1.strstr() 函数搜索一个字符串在另一个字符串中的第一次出现。
2.找到所搜索的字符串，则该函数返回第一次匹配的字符串的地址；
3.如果未找到所搜索的字符串，则返回NULL。
*/
static u8 *JudgeStr(u16 waittime)  //返回指针的函数
{
	char *data;
	u8 str[8];
	
	str[0]=0xef;
	str[1]=0x01;
	str[2]=AS608Addr>>24;
	str[3]=AS608Addr>>16;
	str[4]=AS608Addr>>8;
	str[5]=AS608Addr;
	str[6]=0x07;
	str[7]='\0';
	USART2_RX_STA=0;
	while(--waittime)
	{
		delay_ms(1);
		if(USART2_RX_STA&0X8000)//接收到一次数据
		{
			USART2_RX_STA=0;
			data=strstr((const char*)USART2_RX_BUF,(const char*)str);
			if(data)
				return (u8*)data;	
		}
	}
	return 0;
}


//录入图像 PS_GetImage
//功能:探测手指，探测到后录入指纹图像存于ImageBuffer。 
//模块返回确认字


/**
* @Description  探测手指，探测到后录入指纹图像存于 ImageBuffer，并返回录入成功确认码。若探测不到手指，直接返回无手指确认码。
* @param	None
* @return   确认字
*/
u8 PS_GetImage(void)
{
    u16 temp;
    u8  ensure;
	u8  *data;    //强制使指针data指向存放类型为一个字节长度数据的数组
	SendHead();	  //发送包头 0xEF01
	SendAddr();   //发送默认地址 0XFFFFFFFF 
	SendFlag(0x01);//命令包标识
	SendLength(0x03); //发送包长度03H
	SendCmd(0x01);  //发送指令码01H
    temp =  0x01+0x03+0x01;  
	SendCheck(temp);  //发送校验和05H
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];  //以data为起始地址的数组的第10个字节  可以看指纹处理类指令
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  将 ImageBuffer 中的原始图像生成指纹特征,文件存于 CharBuffer1 或 CharBuffer2.(看AS608指纹模块中文资料 图像生成特征 Img2Tz)  
* @param	BufferID(特征缓冲区号)  缓冲区 CharBuffer1、CharBuffer2 的 BufferID 分别为 1h 和 2h
* @return   确认字  
            确认码=00H 表示生成特征成功
			确认码=01H 表示收包有错；
			确认码=06H 表示指纹图像太乱而生不成特征；
			确认码=07H 表示指纹图像正常，但特征点太少而生不成特征；
			确认码=15H 表示图像缓冲区内没有有效原始图而生不成图像；
*/

u8 PS_GenChar(u8 BufferID)
{
	u16 temp;
    u8  ensure;
	u8  *data;
	SendHead();  //发送包头
	SendAddr();  //发送模块地址
	SendFlag(0x01);//命令包标识
	SendLength(0x04);//发送包长度
	SendCmd(0x02);//发送指令码
	MYUSART_SendData(BufferID);
	temp = 0x01+0x04+0x02+BufferID;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;
}

/**
* @Description  模块精确比对（1:1）CharBuffer1 与 CharBuffer2 中的特征文件，并给比对结果。
* @param	none
* @return   确认字  
            确认码=00H 表示指纹匹配；
			确认码=01H 表示收包有错；
			确认码=08H 表示指纹不匹配；
*/
u8 PS_Match(void)
{
	u16 temp;
  u8  ensure;
	u8  *data;
	SendHead();  //发送包头
	SendAddr();  //发送模块地址
	SendFlag(0x01);//发送命令包标识
	SendLength(0x03); //发送包长度
	SendCmd(0x03); //发送指令码
	temp = 0x01+0x03+0x03; 
	SendCheck(temp);  //发送校验码0x07
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;
}



//搜索指纹 PS_Search
//功能:以CharBuffer1或CharBuffer2中的特征文件搜索整个或部分指纹库.若搜索到，则返回页码。			
//参数:  BufferID @ref CharBuffer1	CharBuffer2
//说明:  模块返回确认字，页码（相配指纹模板）

/**
* @Description  以CharBuffer1 或 CharBuffer2 中的特征文件搜索整个或部分指纹库。若搜索到，则返回页码
* @param	BufferID 特征缓冲区号
* @param	StartPage 起始页
* @param	PageNum 页数
* @param	SearchResult *p 存储指纹ID和匹配得分
* @return   确认字  
            确认码=00H 表示搜索到；
			确认码=01H 表示收包有错；
			确认码=09H 表示没搜索到；此时页码与得分为 0
该指令执行后，特征缓冲区中的内容不变。
*/
u8 PS_Search(u8 BufferID,u16 StartPage,u16 PageNum,SearchResult *p)
{
	u16 temp;
    u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x08);
	SendCmd(0x04);
	MYUSART_SendData(BufferID);
	MYUSART_SendData(StartPage>>8);
	MYUSART_SendData(StartPage);
	MYUSART_SendData(PageNum>>8);
	MYUSART_SendData(PageNum);
	temp = 0x01+0x08+0x04+BufferID
	+(StartPage>>8)+(u8)StartPage
	+(PageNum>>8)+(u8)PageNum;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
	{
		ensure = data[9];
		p->pageID   =(data[10]<<8)+data[11];  //页码长度为2字节
		p->mathscore=(data[12]<<8)+data[13];//	得分长度为2字节
	}
	else
		ensure = 0xff;
	return ensure;	
}


/**
* @Description  将 CharBuffer1 与 CharBuffer2 中的特征文件合并生成模板，结果存于CharBuffer1 与 CharBuffer2(两者内容相同)。
* @param	None
* @return   确认字  
            确认码=00H 表示合并成功；
			确认码=01H 表示收包有错；
			确认码=0aH 表示合并失败（两枚指纹不属于同一手指）；
*/
u8 PS_RegModel(void)
{
	u16 temp;
  u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x03);
	SendCmd(0x05);
	temp = 0x01+0x03+0x05;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;		
}


/**
* @Description  将指定的特征缓冲区（Buffer1 或 Buffer2）中的模板数据存储到 Flash 指纹库中指定位置。
* @param	BufferID 缓冲区号
* @param	PageID   指纹库位置号，两个字节，高字节在前
* @return   确认字  
            确认码=00H 表示合并成功；
			确认码=01H 表示收包有错；
			确认码=0aH 表示合并失败（两枚指纹不属于同一手指）；
*/
u8 PS_StoreChar(u8 BufferID,u16 PageID)
{
	u16 temp;
  u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x06);
	SendCmd(0x06);
	MYUSART_SendData(BufferID);
	MYUSART_SendData(PageID>>8);
	MYUSART_SendData(PageID);
	temp = 0x01+0x06+0x06+BufferID
	+(PageID>>8)+(u8)PageID;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;	
}


/**
* @Description  删除模块指纹库中指定的一段（指定 ID 号开始的 N 个指纹模板）模板
* @param	PageID 指纹库模板号
* @param	N 删除的模板个数。
* @return   确认字  
            确认码=00H 表示删除模板成功；
			确认码=01H 表示收包有错；
			确认码=10H 表示删除模板失败；
*/
u8 PS_DeletChar(u16 PageID,u16 N)
{
	u16 temp;
  u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x07);
	SendCmd(0x0C);
	MYUSART_SendData(PageID>>8); //发送指令码
	MYUSART_SendData(PageID);
	MYUSART_SendData(N>>8);  //发送页码
	MYUSART_SendData(N);
	temp = 0x01+0x07+0x0C+(PageID>>8)+(u8)PageID+(N>>8)+(u8)N;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  删除模块中指纹库内所有指纹模板
* @param	None
* @return   确认字  
            确认码=00H 表示清空成功；
			确认码=01H 表示收包有错；
			确认码=11H 表示清空失败；
*/
u8 PS_Empty(void)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);   //命令包标识
	SendLength(0x03);
	SendCmd(0x0D);
	temp = 0x01+0x03+0x0D;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  工作参数设置（参见 4.4 系统配置参数）
* @param	RegNum 参数序号
* @param	DATA 内容
* @return   确认字
			确认码=00H 表示 OK
			确认码=01H 表示收包有错；
			确认码=1aH 表示寄存器序号有误；
*/
u8 SetSysPara(u8 RegNum,u8 DATA)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x05);
	SendCmd(0x0E);
	MYUSART_SendData(RegNum);
	MYUSART_SendData(DATA);
	temp = 0x01+0x05+0x0E+RegNum+DATA;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	if(ensure==0)
		//printf("\r\n设置参数成功！");
	LCD_Display_Words(1,0,"设置参数成功！");	
	else
		//printf("\r\n%s",EnsureMessage(ensure));
	LCD_Display_Words(1,0,"错误");	
	return ensure;
}


/**
* @Description  读取模块的状态寄存器和系统基本配置参数 
* @param	SysPara *p 用来存储数据
* @return   确认字
			确认码=00H 表示 OK
			确认码=01H 表示收包有错；
*/
u8 PS_ReadSysPara(SysPara *p)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x03);
	SendCmd(0x0F);
	temp = 0x01+0x03+0x0F;
	SendCheck(temp);
	data=JudgeStr(1000);
	if(data)
	{
		ensure = data[9];   //确认码
		p->PS_max = (data[14]<<8)+data[15]; //指纹库大小
		p->PS_level = data[17]; //安全等级
		p->PS_addr=(data[18]<<24)+(data[19]<<16)+(data[20]<<8)+data[21]; //设备地址 4个字节
		p->PS_size = data[23];  //数据包大小
		p->PS_N = data[25];
	}		
	else
		ensure=0xff;
	
	return ensure;
}


/**
* @Description  设置模块地址
* @param	PS_addr 模块的新地址
* @return   确认字
			确认码=00H 表示生成地址成功
			确认码=01H 表示收包有错；
*/
u8 PS_SetAddr(u32 PS_addr)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x07);
	SendCmd(0x15);
	MYUSART_SendData(PS_addr>>24);
	MYUSART_SendData(PS_addr>>16);
	MYUSART_SendData(PS_addr>>8);
	MYUSART_SendData(PS_addr);
	temp = 0x01+0x07+0x15+(u8)(PS_addr>>24)+(u8)(PS_addr>>16)+(u8)(PS_addr>>8) +(u8)PS_addr;				
	SendCheck(temp);
	AS608Addr=PS_addr;//发送完指令，更换地址
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;	
		AS608Addr = PS_addr;
	if(ensure==0x00)
		//printf("\r\n设置地址成功！");
	LCD_Display_Words(1,0,"n设置地址成功！");		
	else
		//printf("\r\n%s",EnsureMessage(ensure));
	LCD_Display_Words(1,0,"错误");	
	return ensure;
}


/**
* @Description  上位机将数据写入记事本指定 Flash 页,模块内部为用户开辟了256bytes的FLASH空间用于存用户记事本,该记事本逻辑上被分成 16 个页。
* @param	NotePageNum 页码
* @param	Byte32 用户信息
* @return   确认字
			确认码=00H 表示 OK；
			确认码=01H 表示收包有错；
*/
u8 PS_WriteNotepad(u8 NotePageNum,u8 *Byte32)
{
	u16 temp;
	u8  ensure,i;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(36);
	SendCmd(0x18);
	MYUSART_SendData(NotePageNum);
	for(i=0;i<32;i++)
	{
		 MYUSART_SendData(Byte32[i]);
		 temp += Byte32[i];
	}
	temp =0x01+36+0x18+NotePageNum+temp;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
		ensure=data[9];
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  读取记事本指定页数据,该指令与WriteNotePad对应
* @param	NotePageNum 页码
* @param	Byte32 用户信息
* @return   确认字
			确认码=00H 表示 OK；
			确认码=01H 表示收包有错；
*/
u8 PS_ReadNotepad(u8 NotePageNum,u8 *Byte32)
{
	u16 temp;
	u8  ensure,i;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x04);
	SendCmd(0x19);
	MYUSART_SendData(NotePageNum);
	temp = 0x01+0x04+0x19+NotePageNum;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
	{
		ensure=data[9];
		for(i=0;i<32;i++)
		{
			Byte32[i]=data[10+i];
		}
	}
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  读取记事本指定页数据,该指令与WriteNotePad对应
* @param	BufferID  缓冲区号
* @param	StartPage 起始页
* @param	PageNum 页码
* @return   模块返回确认字+页码（相配指纹模板）
*/
u8 PS_HighSpeedSearch(u8 BufferID,u16 StartPage,u16 PageNum,SearchResult *p)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x08);
	SendCmd(0x1b);
	MYUSART_SendData(BufferID);
	MYUSART_SendData(StartPage>>8);
	MYUSART_SendData(StartPage);
	MYUSART_SendData(PageNum>>8);
	MYUSART_SendData(PageNum);
	temp = 0x01+0x08+0x1b+BufferID+(StartPage>>8)+(u8)StartPage+(PageNum>>8)+(u8)PageNum;
	SendCheck(temp);
	data=JudgeStr(2000);
 	if(data)
	{
		ensure=data[9];
		p->pageID 	=(data[10]<<8) +data[11];
		p->mathscore=(data[12]<<8) +data[13];
	}
	else
		ensure=0xff;
	return ensure;
}


/**
* @Description  读取指纹模板数
* @param	ValidN  读取有效指纹个数
* @return   模块返回确认字+页码（相配指纹模板）
*/
u8 PS_ValidTempleteNum(u16 *ValidN)
{
	u16 temp;
	u8  ensure;
	u8  *data;
	SendHead();
	SendAddr();
	SendFlag(0x01);//命令包标识
	SendLength(0x03);
	SendCmd(0x1d);
	temp = 0x01+0x03+0x1d;
	SendCheck(temp);
	data=JudgeStr(2000);
	if(data)
	{
		ensure=data[9];
		*ValidN = (data[10]<<8) +data[11];
	}		
	else
		ensure=0xff;
	
	return ensure;
}


/**
* @Description  与AS608握手
* @param	PS_Addr  模块地址
* @return   模块返新地址（正确地址）
*/
u8 PS_HandShake(u32 *PS_Addr)
{
	SendHead();
	SendAddr();
	MYUSART_SendData(0X01);
	MYUSART_SendData(0X00);
	MYUSART_SendData(0X00);	
	delay_ms(200);
	if(USART2_RX_STA&0X8000)//接收到数据
	{		
		if(//判断是不是模块返回的应答包				
					USART2_RX_BUF[0]==0XEF
				&&USART2_RX_BUF[1]==0X01
				&&USART2_RX_BUF[6]==0X07
			)
			{
				*PS_Addr=(USART2_RX_BUF[2]<<24) + (USART2_RX_BUF[3]<<16)
								+(USART2_RX_BUF[4]<<8) + (USART2_RX_BUF[5]);
				USART2_RX_STA=0;
				return 0;
			}
		USART2_RX_STA=0;					
	}
	return 1;		
}


/**
* @Description  模块应答包确认码信息解析
* @param	ensure  确认码
* @return   解析确认码错误信息返回信息
*/
const char *EnsureMessage(u8 ensure) 
{
	const char *p;
	switch(ensure)
	{
		case  0x00:
			p="OK";break;		
		case  0x01:
			p="数据包接收错误";break;
		case  0x02:
			p="传感器上没有手指";break;
		case  0x03:
			p="录入指纹图像失败";break;
		case  0x04:
			p="指纹图像太干、太淡而生不成特征";break;
		case  0x05:
			p="指纹图像太湿、太糊而生不成特征";break;
		case  0x06:
			p="指纹图像太乱而生不成特征";break;
		case  0x07:
			p="指纹图像正常，但特征点太少（或面积太小）而生不成特征";break;
		case  0x08:
			p="指纹不匹配";break;
		case  0x09:
			p="没搜索到指纹";break;
		case  0x0a:
			p="特征合并失败";break;
		case  0x0b:
			p="访问指纹库时地址序号超出指纹库范围";
		case  0x10:
			p="删除模板失败";break;
		case  0x11:
			p="清空指纹库失败";break;	
		case  0x15:
			p="缓冲区内没有有效原始图而生不成图像";break;
		case  0x18:
			p="读写 FLASH 出错";break;
		case  0x19:
			p="未定义错误";break;
		case  0x1a:
			p="无效寄存器号";break;
		case  0x1b:
			p="寄存器设定内容错误";break;
		case  0x1c:
			p="记事本页码指定错误";break;
		case  0x1f:
			p="指纹库满";break;
		case  0x20:
			p="地址错误";break;
		default :
			p="模块返回确认码有误";break;
	}
	return p;	
}


/***************************************** 指纹识别模块功能函数 *****************************************/
//显示错误信息
static void ShowErrMessage(u8 ensure)
{
	
}

/**
* @Description  在初始化完成后调用，用来与指纹模块握手，检测指纹模块和获取一些模块的信息
* @param	None
* @return   None
*/
void Shake_to_AS608(void)
{
	u8 ensure;
	while(PS_HandShake(&AS608Addr))			/*与AS608模块握手*/
	{
		delay_ms(400);
		//LCD_Display_Words(0,0,"未检测到指纹模块");
		delay_ms(800);
		//LCD_Display_Words(1,0,"尝试重新连接模块");
	}
	
//	LCD_Display_Words(0,0,"指纹模块通讯成功");
		ensure = PS_ValidTempleteNum(&ValidN);	/*读库指纹个数*/  
//	if(ensure!=0x00)
//		ShowErrMessage(ensure);				/*显示确认码错误信息*/
	ensure = PS_ReadSysPara(&AS608Para);  		/*读参数 */	//这一步很重要，未成功执行这个函数将会导致刷指纹出错
	if(ensure==0x00)
	{
		
	}
	else
		ShowErrMessage(ensure);	
	delay_ms(1000);
	LCD_Clear();
}



/**
* @Description  录指纹
* @param	FR_ID  要录入的指纹ID
* @return   None
*/
void Add_FR(u16 FR_ID)
{
	u8 ensure ,processnum=0;
	u16 ID;
	while(1)
	{
		switch (processnum)
		{	/*第一次录入*/
			case 0:
				LCD_Clear();
				while(1)
				{
					LCD_Display_Words(0,0,"    请按指纹");
					LCD_Display_Words(3,0,"BACK");
					
					zhiwen_key = Key_Scan();
					if(zhiwen_key == back)
					{
						state = 2;  //回到录指纹的界面
						return;
					}
					
					ensure = PS_GetImage();
					if(ensure==0x00) 
					{
						ensure = PS_GenChar(CharBuffer1);//生成特征
						if(ensure==0x00)
						{
							processnum = 1;//跳到第二步
							break;
						}				
					}
				}				
				continue;
			/*第二次录入*/
			case 1:
				while(1)
				{
					LCD_Display_Words(3,0,"BACK");
					
					zhiwen_key=Key_Scan();
					if(zhiwen_key == back)
					{
						state = 2;  //回到录指纹的界面
						return;
					}
					ensure = PS_GetImage();
					if(ensure==0x00) 
					{
						ensure = PS_GenChar(CharBuffer2);//生成特征
						if(ensure==0x00)
						{
							processnum=2;//跳到第三步
							break;
						}
					}
				}				
				continue;
			//比较两次指纹
			case 2:
				while(1)
				{
					zhiwen_key=Key_Scan();
					if(zhiwen_key == back)
					{
						state=2;  //回到录指纹的界面
						return;
					}
					
					ensure=PS_Match(); //精确比对两枚指纹特征
					if(ensure==0x00) 
					{
						processnum=3;//跳到第四步
						break;
					}
					else 
					{
						LCD_Display_Words(2,0,"两次指纹不同");	
						delay_ms(500);
						processnum=0;//跳回第一步
						break;						
					}
				}
				continue;
			//合并特征（生成模板）
			case 3:
				while(1)
				{
					zhiwen_key=Key_Scan();
					if(zhiwen_key == back)
					{
						state = 2;  //回到录指纹的界面
						return;
					}
					
					ensure = PS_RegModel();  //合并特征
					if(ensure==0x00) 
					{
						processnum=4;//跳到第五步
						break;
					}
					else 
					{
						LCD_Display_Words(2,0,"    存储失败");	
						delay_ms(500);
						processnum=0;
						break;
					}
				}
				continue;
			//存储指纹	
			case 4:
				while(1)
				{
					do
					ID=FR_ID;
					while(!(ID<AS608Para.PS_max));//输入ID必须小于指纹容量的最大值
					
					ensure=PS_StoreChar(CharBuffer2,ID);//储存模板
					if(ensure==0x00) 
					{
						add_zhiwen_flag = 1;	//标志录入指纹成功					
						PS_ValidTempleteNum(&ValidN);//读库指纹个数
						LCD_Display_Words(2,0,"  录入指纹成功");
						delay_ms(800);
						return ;
					}
					else 
					{
						LCD_Display_Words(2,0,"    存储失败");	
						delay_ms(500);
						processnum=0;
						break;
					}						
				}
				continue;					
		}			
	}
}


/**
* @Description  删除指纹
* @param	FR_ID  要删除的指纹ID
* @return   None
*/
void Del_FR(u16 FR_ID)
{
	u8  ensure;
	ensure=PS_DeletChar(FR_ID,1);//删除flash数据库中指定ID号开始的1个指纹模板
	if(ensure==0)
	{	
		LCD_Clear();
		LCD_Display_Words(1,0,"  删除指纹成功");
		delay_ms(800);	
	}
	PS_ValidTempleteNum(&ValidN);//读库有效指纹个数
}


/**
* @Description  刷指纹
* @param	None  
* @return   None
*/
void Press_FR(void)
{
	SearchResult seach;
	u8 ensure;
	ensure = PS_GetImage();  //探测手指，探测到后录入指纹图像存于 ImageBuffer
	if(ensure == 0x00)//获取图像成功 
	{	
		ensure = PS_GenChar(CharBuffer1);  //将 ImageBuffer 中的原始图像生成指纹特征,文件存于 CharBuffer1
		if(ensure == 0x00) //生成特征成功
		{		
			ensure=PS_HighSpeedSearch(CharBuffer1,0,AS608Para.PS_max,&seach);
			if(ensure==0x00)//搜索成功
			{
				zhi_wen_flag = 1;			//代表指纹正确
				zhiwen_ID = seach.pageID;	//更新指纹ID值
			}				
	  }
	}
		
}



